{{- define "shared-helpers.services" -}}
{{- if .Values.rollout.enabled }}
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.service.activeServiceName }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "shared-helpers.labels" . | nindent 4 }}
spec:
  type: ClusterIP
  ports:
    - port: 80
      targetPort: {{ .Values.healthCheck.port }}
      protocol: TCP
  selector:
    {{- include "shared-helpers.selectorLabels" . | nindent 4 }}
---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.service.previewServiceName }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "shared-helpers.labels" . | nindent 4 }}
spec:
  type: ClusterIP
  ports:
    - port: 80
      targetPort: {{ .Values.healthCheck.port }}
      protocol: TCP
  selector:
    {{- include "shared-helpers.selectorLabels" . | nindent 4 }}
{{- end }}
{{- end }}
